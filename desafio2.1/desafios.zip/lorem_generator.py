import sys
n = int(sys.argv[1])
lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean mollis, turpis quis vehicula feugiat, leo justo posuere ante, vitae luctus tellus eros vel purus. Duis fermentum mattis lorem, ultrices ornare massa fermentum vitae. Phasellus viverra dapibus sollicitudin. Nam eu leo accumsan, porta diam ut, aliquet ligula. Phasellus dui lectus, ultricies et aliquam et, venenatis quis metus. Proin bibendum enim eu arcu condimentum tempus. Phasellus sit amet aliquam libero."
print(n*lorem)
