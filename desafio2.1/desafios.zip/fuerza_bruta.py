password = input("Ingrese contraseña\n")
# ej password = gato
# print(intentos) ej 43 intentos