n = int(input("ingrese numero de filas\n"))
contain = ""
for i in range(1, n + 1):
    contain += str(1 * i)
    print(contain)